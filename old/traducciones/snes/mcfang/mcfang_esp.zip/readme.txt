Juego: The Twisted Tales of Spike McFang
Versi�n: 1.0b (100%)
Autor: Predicador (http://club.idecnet.com/~predi/index.htm)
Grupo: Sayans Traductions (http://pagina.de/Sayans_Traductions)
Email: predi@idecnet.com



NOTAS

El texto ha sido traducido en un 100%. Tan solo han quedado
detalles como la �, y los signos de acentuaci�n. Algunas
palabras del men� no han podido ser traducidas.

