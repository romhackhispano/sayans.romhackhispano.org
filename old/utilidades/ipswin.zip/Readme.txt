===============================================================================
IPSWin 2.0 - README
===============================================================================

DISCLAIMER
The author is not responsable for any improper and dangerous use of the program
and is not in any way responsable for any damage derived from the use of 
IPSWin.

HOW TO USE
Simply select a file to patch and a valid IPS file to patch it. Click on Patch!
Button and enjoy the progress dialog box! The program will notify you when the
patching completes.
The option "Backup Copy" will create a backup of your file. Keep in mind that
even if IPSWin is generally able to recover your original files if the patching
goes wrong, it's highly raccomended to make a backup copy just to be sure...
"Log File" can help to find some malfunction either in the IPS file or in the program. 

NOTE ON ZIP SUPPORT
ZIP file support is ensured using a modified version of ZLIB made by myself to optimize the size of the program. If you're patching using ZIP files you'll notice that the process will be slower (a bunch of seconds, not more) than
patching unzipped files. The surplus time is used to decode and encode ZIP
information 8)
The two conditions below are based on the standard mode of shipping of IPS
files and ROMs: 
- The program will fetch the IPS file in the patch ZIP and will use the first 
  IPS file that it will encounter (this to avoid the presence of readme files
  that can screw up the patching).
- The program will patch the first file found the ZIP archive to patch. 

ABOUT SOME DUMB QUESTIONS I RECEIVED
Well IPSWin CANNOT be used to update your favorite commercial programs...
IPSWin is a tool to apply IPS files not some application that acts like Live
Update, Windows Update or similar programs.


HOMEPAGE
IPSWin is at
http://zerosoft.zophar.net

THE AUTHOR
Of course the author is Z.e.r.o, contact me at:
z.e.r.o@softhome.net
