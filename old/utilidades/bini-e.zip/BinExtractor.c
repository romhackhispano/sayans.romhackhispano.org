// Bin Extractor 1.0 - by Pablito's :)
// Copyright 2002 Sayans Traductions
//
// Eres el libre de incluir el c�digo del programa en tu propio programa,
// as� como de modificarlo seg�n tus necesidades. Aunque si lo haces,
// te agradecer�a que me mencionaras como autor :)


#include <stdio.h>

int main(int argc, char *argv[])
{
	FILE *archivo_origen;
	FILE *archivo_nuevo;

	unsigned long int offset_inicial, bytes_extraer;

	int i;

	char archivo1[35], archivo2[35];
	char caracter;

	// Si se escriben los datos necesarios en la l�nea de comandos, �stos se guardan
	// y se pasa al siguiente punto del programa. Si no, se pregunta por todos ellos.
	if (argc == 5)
	{
		sscanf(argv[1], "%s", &archivo1);
		sscanf(argv[2], "%s", &archivo2);
		sscanf(argv[3], "%d", &offset_inicial);
		sscanf(argv[4], "%d", &bytes_extraer);
	}

	else
	{
		printf("\nBin Extractor 1.0 - by Pablito's ;)\nSayans Traductions (http://sayans.emumania.com)\n\n");

		printf("Archivo de donde extraer bytes: ");
		scanf("%s", &archivo1);

		printf("Archivo donde se van a extraer los bytes: ");
		scanf("%s", &archivo2);

		printf("Offset inicial de los bytes a extraer (en decimal): ");
		scanf("%d", &offset_inicial);

		printf("Bytes a extraer: ");
		scanf("%d", &bytes_extraer);
	}

	// Abrir el archivo de origen para leer. Antes de seguir se comprueba que est� abierto.
	archivo_origen = fopen(archivo1, "rb");

	if (archivo_origen == NULL)
       {
       printf("No se puede abrir el fichero.\n");
       exit(1);
       }

	// Crear el archivo nuevo para escribir en �l. Antes de seguir se comprueba que est� creado.
	archivo_nuevo = fopen(archivo2, "wb");

	if (archivo_nuevo == NULL)
       {
       printf("No se puede crear el fichero.\n");
       exit(1);
       }

	// Situarse en el offset inicial a partir del cual se van a extraer bytes
	fseek(archivo_origen, offset_inicial, SEEK_SET);

	printf("\nExtrayendo bytes...");
	
	// Leer un byte y escribirlo en el archivo haciendo un loop hasta que no haya m�s bytes a extraer
	for (i = 0; i != bytes_extraer; i++)
	{
		caracter = getc(archivo_origen);
		
		if (feof(archivo_origen))
		{
			// Cerrar los archivos y salir
			fclose(archivo_origen);
			fclose(archivo_origen);
			return 0;
		}

		putc(caracter, archivo_nuevo);
	}

	printf("\nFinalizada la extraccion");

	// Cerrar los archivos
	fclose(archivo_origen);
	fclose(archivo_nuevo);

	return 0;
}