// Bin Inserter 1.0 - by Pablito's :)
// Copyright 2002 Sayans Traductions
//
// Eres el libre de incluir el c�digo del programa en tu propio programa,
// as� como de modificarlo seg�n tus necesidades. Aunque si lo haces,
// te agradecer�a que me mencionaras como autor :)


#include <stdio.h>

int main(int argc, char *argv[])
{
	FILE *archivo_origen;
	FILE *archivo_insertar;

	unsigned long int offset_inicial;

	int i;

	char archivo1[35], archivo2[35];
	char caracter;

	// Si se escriben los datos necesarios en la l�nea de comandos, �stos se guardan
	// y se pasa al siguiente punto del programa. Si no, se pregunta por todos ellos.
	if (argc == 4)
	{
		sscanf(argv[1], "%s", &archivo1);
		sscanf(argv[2], "%s", &archivo2);
		sscanf(argv[3], "%d", &offset_inicial);
	}

	else
	{
		printf("\nBin Inserter 1.0 - by Pablito's ;)\nSayans Traductions (http://sayans.emumania.com)\n\n");

		printf("Archivo donde insertar bytes: ");
		scanf("%s", &archivo1);

		printf("Archivo del que se van a leer los bytes a insertar: ");
		scanf("%s", &archivo2);

		printf("Offset inicial donde comenzar a insertar bytes (en decimal): ");
		scanf("%d", &offset_inicial);
	}

	// Abrir el archivo de origen para leer. Antes de seguir se comprueba que est� abierto.
	archivo_origen = fopen(archivo2, "rb");

	if (archivo_origen == NULL)
       {
       printf("No se puede abrir el fichero.\n");
       exit(1);
       }

	// Crear el archivo nuevo para escribir en �l. Antes de seguir se comprueba que est� creado.
	archivo_insertar = fopen(archivo1, "ab");

	if (archivo_insertar == NULL)
       {
       printf("No se puede crear el fichero.\n");
       exit(1);
       }

	// Situarse en el offset inicial a partir del cual se van a extraer bytes
	fseek(archivo_insertar, offset_inicial, SEEK_SET);

	printf("\nInsertando bytes...");
	
	// Leer un byte y escribirlo en el archivo haciendo un loop hasta que no haya m�s bytes a extraer
	while (!feof(archivo_insertar))
	{
		caracter = getc(archivo_origen);

		if (feof(archivo_origen))
		{
			// Cerrar los archivos y salir
			fclose(archivo_origen);
			fclose(archivo_insertar);
			return 0;
		}

		putc(caracter, archivo_insertar);
	}

	printf("\nFinalizada la insercion");

	// Cerrar los archivos
	fclose(archivo_origen);
	fclose(archivo_insertar);

	return 0;
}